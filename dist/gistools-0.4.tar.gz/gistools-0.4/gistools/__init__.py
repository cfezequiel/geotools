import os
import exifread
import exiftool

def test():
    return 'It works!'


